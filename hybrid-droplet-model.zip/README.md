# Hybrid Droplet Splashing Model

This repository contains code to reproduce the results in the paper *A Hybrid Viscous–Cushion Model for Droplet Splashing Across Ambient Pressure*.

## Structure
- `digitize/`: Scripts for extracting radius-time data from experimental figures
- `model/`: Hybrid model implementation and pressure-dependent fitting
- `results/`: Scripts for plotting overlays and RMSE validation
- `appendix/`: Modal analysis of pre-contact air layer (optional extension)

## Requirements
Install dependencies with:

```bash
pip install -r requirements.txt
```

## Usage
1. Digitize data using scripts in `digitize/`
2. Run the hybrid model from `model/hybrid_model.py`
3. Use plotting scripts in `results/` to generate figures
